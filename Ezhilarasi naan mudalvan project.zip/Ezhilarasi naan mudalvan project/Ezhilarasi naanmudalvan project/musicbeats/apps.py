from django.apps import AppConfig


class MusicbeatsConfig(AppConfig):
    name = "musicbeats"
